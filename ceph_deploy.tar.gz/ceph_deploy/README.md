test
# ceph_deploy
