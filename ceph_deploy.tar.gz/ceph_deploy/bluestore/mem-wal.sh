dd if=/dev/zero of=/dev/shm/ceph-wal/osd-0.wal bs=4M count=0 seek=2560
dd if=/dev/zero of=/dev/shm/ceph-wal/osd-1.wal bs=4M count=0 seek=2560
dd if=/dev/zero of=/dev/shm/ceph-wal/osd-2.wal bs=4M count=0 seek=2560

losetup /dev/loop0 /dev/shm/ceph-wal/osd-0.wal
losetup /dev/loop1 /dev/shm/ceph-wal/osd-1.wal
losetup /dev/loop2 /dev/shm/ceph-wal/osd-2.wal
